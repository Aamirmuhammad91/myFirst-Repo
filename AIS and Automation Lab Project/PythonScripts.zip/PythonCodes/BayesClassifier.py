import numpy as np
from numpy import genfromtxt
from sklearn.naive_bayes import GaussianNB
from sklearn.model_selection import train_test_split
from sklearn import metrics
from joblib import dump, load

data_wall = np.array(genfromtxt('AllDataFiles/WallFeatures.csv',delimiter=','))
data_human = np.array(genfromtxt('AllDataFiles/HumanFeatures.csv',delimiter=','))
data_car = np.array(genfromtxt('AllDataFiles/CarFeatures.csv',delimiter=','))

set1 = np.concatenate((data_wall,data_human,data_car)) # all the data in same variable

row_data_wall = np.repeat(-1,data_wall.shape[0])
row_data_human = np.repeat(0,data_human.shape[0])
row_data_car = np.repeat(1,data_car.shape[0])

set2 = np.concatenate((row_data_wall,row_data_human,row_data_car))

set1_train, set1_test, set2_train, set2_test = train_test_split(set1, set2, train_size=0.8)# split the data again, 80% for train or 20% for test

clfr = GaussianNB()# training started
clfr.fit(set1_train, set2_train)# actual training
dump(clfr,'Bayes_Classifier.joblib') # save the classifier in .joblib

load_clfr = load('Bayes_Classifier.joblib') # loaded into load_clfr variable
set2_pred = load_clfr.predict(set1_test)# prediction

print("Accuracy:",metrics.accuracy_score(set2_test, set2_pred))# accuracy after comparison between set2_test (actual) abd set2_pred (predicted values)