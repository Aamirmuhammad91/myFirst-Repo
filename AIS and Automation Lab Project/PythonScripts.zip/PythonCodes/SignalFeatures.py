import numpy as np
from numpy import genfromtxt
import tsfresh

data_wall = np.array(genfromtxt('AllDataFiles/Wall.csv',delimiter=','))
for x in range(data_wall.shape[0]): #for each row in data calculating the feature
    Sig_data_wall = np.array([data_wall[x][3500:]]) #cut the starting initial data upto 3500 samples
    feature_energy = tsfresh.feature_extraction.feature_calculators.abs_energy(Sig_data_wall[0])
    feature_sum = tsfresh.feature_extraction.feature_calculators.sum_values(Sig_data_wall[0])
    feature_std = tsfresh.feature_extraction.feature_calculators.standard_deviation(Sig_data_wall[0])
    all_features = np.array([[feature_energy, feature_sum, feature_std]])
    new_file = open("AllDataFiles/WallFeatures.csv", "a")
    np.savetxt(new_file,all_features,fmt='%3.8f',delimiter=',')# format: 3.8 float
    new_file.close()

data_human = np.array(genfromtxt('AllDataFiles/Human.csv',delimiter=','))
for x in range(data_human.shape[0]): #for each row in data calculating the feature
    Sig_data_human = np.array([data_human[x][3500:]]) #cut the starting initial data upto 3500 samples
    feature_energy = tsfresh.feature_extraction.feature_calculators.abs_energy(Sig_data_human[0])
    feature_sum = tsfresh.feature_extraction.feature_calculators.sum_values(Sig_data_human[0])
    feature_std = tsfresh.feature_extraction.feature_calculators.standard_deviation(Sig_data_human[0])
    all_features = np.array([[feature_energy, feature_sum, feature_std]])
    new_file = open("AllDataFiles/HumanFeatures.csv", "a")
    np.savetxt(new_file,all_features,fmt='%3.8f',delimiter=',')# format: 3.8 float
    new_file.close()
    
data_car = np.array(genfromtxt('AllDataFiles/Car.csv',delimiter=','))
for x in range(data_car.shape[0]):
    Sig_data_car = np.array([data_car[x][3500:]])
    feature_energy = tsfresh.feature_extraction.feature_calculators.abs_energy(Sig_data_car[0])
    feature_sum = tsfresh.feature_extraction.feature_calculators.sum_values(Sig_data_car[0])
    feature_std = tsfresh.feature_extraction.feature_calculators.standard_deviation(Sig_data_car[0])
    all_features = np.array([[feature_energy, feature_sum, feature_std]])
    new_file = open("AllDataFiles/CarFeatures.csv", "a")
    np.savetxt(new_file, all_features, fmt='%3.8f', delimiter=',')  # format: 3.8 float
    new_file.close()