import redpitaya_scpi as scpi
import numpy as np
import tsfresh
from joblib import load
import time

rp = scpi.scpi('192.168.128.1')
while 1:
    rp.tx_txt('ACQ:DEC 64')
    rp.tx_txt('ACQ:TRIG EXT_PE')
    rp.tx_txt('ACQ:TRIG:DLY 8192')
    rp.tx_txt('ACQ:START')
    while 1:
        rp.tx_txt('ACQ:TRIG:STAT?')
        if rp.rx_txt() == 'TD':
            break
    rp.tx_txt('ACQ:SOUR1:DATA?')
    str = rp.rx_txt()[1:-1]
    signal_data = np.fromstring(str,dtype=float,sep=',')
    Sig_data = np.array(signal_data[3500:])
    feature_energy = tsfresh.feature_extraction.feature_calculators.abs_energy(Sig_data)
    feature_sum = tsfresh.feature_extraction.feature_calculators.sum_values(Sig_data)
    feature_std = tsfresh.feature_extraction.feature_calculators.standard_deviation(Sig_data)
    all_features = np.array([[feature_energy, feature_sum, feature_std]])
    load_clfr = load('Bayes_Classifier.joblib') # already trained model
    real_time_pred = load_clfr.predict(all_features)# real time prediction
    if real_time_pred == -1:
        rp.tx_txt('DIG:PIN LED0,1')  # digital pin, str(1) means ON + ',' + str(0))
        rp.tx_txt('DIG:PIN LED1,0')
        rp.tx_txt('DIG:PIN LED2,0')
    elif real_time_pred == 0:
        rp.tx_txt('DIG:PIN LED0,0')
        rp.tx_txt('DIG:PIN LED1,1')
        rp.tx_txt('DIG:PIN LED2,0')
    elif real_time_pred == 1:
        rp.tx_txt('DIG:PIN LED0,0')
        rp.tx_txt('DIG:PIN LED1,0')
        rp.tx_txt('DIG:PIN LED2,1')
    time.sleep(1)# continiously run after each 1 sec
